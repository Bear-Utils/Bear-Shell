# CD Command
# Sudo (Running Files as Root) -- Not needed
# Cosmetic Stuff
# Make new CMD-OS/BearOS flavors
# apt-get remove/install