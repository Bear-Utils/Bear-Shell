import sys
print(sys.version)
input()